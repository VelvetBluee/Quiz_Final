#Liste mit allen Fragen, die im Quiz vorkommen mit True und False
question_data = [
    {"text": "Die Hochschule Macromedia hat acht Standorte.", "antwort": "True"},
    {"text": "Einer der Studiengänge die die Macromedia anbietet ist Lehramt.", "antwort": "False"},
    {"text": "Geschäftsführer der Macromedia ist  Marc Irmisch-Petit.", "antwort": "True"},
    {"text": "Der Gesellschaftssitz der Macromedia liegt in Stuttgart.", "antwort": "True"},
    {"text": "Die Macromedia bietet die Abschlüsse 'Bachelor of Arts' und 'Bachelor of Science.", "antwort": "True"},
    {"text": "Bis 2015 hieß die Macromedia 'Hochschule für Kunst, Design und populäre Musik'(hKDM).", "antwort": "False"},
    {"text": "Die Macromedia hat viele Partnerhochschulen, unter anderem in Südkorea, Argentinien und Australien.", "antwort": "True"},
    {"text": "Die Hochschule wurde 2005 gegründet.", "antwort": "False"},
    {"text": "Die Macromedia ist eine private Hochschule.", "antwort": "True"},
    {"text": "Man kann das Studium ohne Numerus Clausus starten.", "antwort": "True"},
    {"text": "An der Hochschule Macromedia kann man ausschließlich mit erlangtem Abitur studieren.", "antwort": "False"},
    {"text": "Einer der Schwerpunkte des Studienangebots der Macromedia ist Psychologie.", "antwort": "True"}
]