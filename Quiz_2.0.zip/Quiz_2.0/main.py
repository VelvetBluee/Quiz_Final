from question_model import Question
#importiert die Klasse "Question", damit darauf zugegriffen werden kann
from data import question_data
#importiert die Liste "question_data" aus dem File "data.py", damit auf Fragen zugegriffen werden kann
from quiz_brain import QuizBrain
#importiert aus dem File "quiz_brain.py" die Klasse "QuizBrain". Neue Frage wird gestellt und Antwort geprüft

question_bank = []
for question in question_data:
    question_text = question["text"]
    question_answer = question["antwort"]
    new_question = Question(question_text, question_answer)
    question_bank.append(new_question)
#es wird auf die Fragen zugegriffen, die in der Liste "question_data" in File "data.py" aufgelistet sind

quiz = QuizBrain(question_bank)

while quiz.still_has_questions():
    quiz.next_question()
#falls noch Fragen ausstehen, wird die nächste Frage ausgegeben

print("Du hast das Ende vom Quiz erreicht!")
print(f"Dein finaler Score lautet: {quiz.score}/{quiz.question_number}.")
#Ende.

