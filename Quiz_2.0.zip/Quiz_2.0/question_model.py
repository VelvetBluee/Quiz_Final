#neue Klasse
class Question:

    def __init__(self, q_text, q_antwort):
        self.text = q_text
        self.answer = q_antwort
#Klasse erstellt für die Antwort der Frage!


